create table flights_test(flightno varchar(10), carrier varchar(30), kahase varchar(30), kahatak varchar(30));

insert into flights_test values('JL-120','JET AIRWAYS', 'MUMBAI', 'JAIPUR');
insert into flights_test values('KL-102','KINGFISHER', 'DELHI', 'MUMBAI');
insert into flights_test values('AI-229','INDIAN', 'KOLKATA', 'DELHI');
insert into flights_test values('SP-109','SPICEJET', 'CHENNAI', 'MUMBAI');
insert into flights_test values('GO-120','GO AIR', 'MUMBAI', 'BANGALORE');

