import java.io.IOException;

public class Test {
	public static void main(String[] args) {
		
		Runtime rt = Runtime.getRuntime();
		
		try {
			Process proc = rt.exec("mspaint");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
