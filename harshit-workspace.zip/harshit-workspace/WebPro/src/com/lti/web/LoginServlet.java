package com.lti.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Reading request parameters
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		//Reading values from init-params
		ServletConfig config = getServletConfig();
		String user = config.getInitParameter("User");
		String secret = config.getInitParameter("Pass");
		
		PrintWriter out = response.getWriter();
		//validating login data
		if(userid.equals(user) && passwd.equals(secret))
			out.println("<h1> Login Successful </h1>");
			else
				out.println("<h1> Login Failed </h1>");
	}
		
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
