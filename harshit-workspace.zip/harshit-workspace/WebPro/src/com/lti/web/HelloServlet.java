package com.lti.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private int counter;
	 
	 
	@Override
	public void init() throws ServletException {
		System.out.println("-- Servlet initialised.." );
		counter = 1001;

	}


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		//Setting response MIME type
		response.setContentType("text/html");
		
		//Getting response stream to write generated HTML
		PrintWriter out=response.getWriter();
		
		//Writing HTML response
		out.println("<h1>Hello Beautiful World</h1><hr>");
		out.println("<h2>Welcome To My First Servlet</h2>");
		Date now = new Date();
		out.println("<h3>Visit Time:" + now +"</h3>");
		out.println("<h3>Visitor Number:" + counter++ +"</h3>");
		
		//Getting ServletConfig to read Init-params
		ServletConfig config  = getServletConfig();
		String author = config.getInitParameter("Author");
		out.println("<h3> Servlet Created By:" + author +"</h3>");
		
		
		
	}

}
