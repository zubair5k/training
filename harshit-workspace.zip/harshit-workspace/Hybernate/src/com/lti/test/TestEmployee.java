package com.lti.test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import com.lti.pojo.Employee;
import com.lti.util.HibernateUtil;

public class TestEmployee {
	
	@Test
	public void testSaveEmployee() {
		
		Session session=HibernateUtil.getSession();
		
		Employee emp=new Employee();
		emp.setEmpName("Polo");
		emp.setSalary(10000);
		
		Transaction txn=session.beginTransaction();
		
		session.save(emp);
		
		txn.commit();
		
	}
	
	

}
