package com.lti.test;

import org.hibernate.NaturalIdLoadAccess;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Ignore;
import org.junit.Test;
import com.lti.entity.Book;
//import com.lti.pojo.Book;
import com.lti.util.HibernateUtil;

public class TestBook {
	
	@Test
	@Ignore
	public void saveBookTest() {
		
		Session session=HibernateUtil.getSession();
		
		Book book=new Book();
		book.setAuthor("harshit");
		book.setIsbn(1001);
		book.setPublication("kashyap publication");
		book.setTitle("Zinfdagi");
		
		Book book2=new Book();
		book.setAuthor("harshit2");
		book.setIsbn(1002);
		book.setPublication("kashyap publication2");
		book.setTitle("Zindagi2");
		
		Transaction txn=session.beginTransaction();
		
		session.save(book);
		txn.commit();
		
		
		
	}
	
	@Test
	public void testGetByUniqueKey() {
		
		Session session=HibernateUtil.getSession();
		NaturalIdLoadAccess nila=session.byNaturalId(Book.class);
		
		nila.using("isbn",(long)1001);
		Book book=(Book)nila.load();
		System.out.println("id :"+book.getId());
		System.out.println("isbn :"+book.getIsbn());
		System.out.println("author :"+book.getAuthor());
		System.out.println("title :"+book.getTitle());
		System.out.println("publication :"+book.getPublication());
		
	}

}
