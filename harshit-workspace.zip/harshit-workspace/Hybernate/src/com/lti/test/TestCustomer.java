package com.lti.test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Ignore;
import org.junit.Test;

//import com.lti.pojo.Customer;
import com.lti.util.HibernateUtil;
import com.lti.entity.Customer;
import com.lti.entity.Department;

public class TestCustomer {

	@Test
	@Ignore
	public void testSaveCustomer() {
		Session session = HibernateUtil.getSession();
		Customer cust = new Customer();
		cust.setCustName("Polo2");
		cust.setCreditLimit(5000);
		Transaction txn = session.beginTransaction();
		try {
			session.save(cust);
			txn.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			txn.rollback();
		}
	}

	@Test
	@Ignore
	public void testFetchCustomer() {

		Session session = HibernateUtil.getSession();

		Customer cust = (Customer) session.get(Customer.class, 1);
		System.out.println("name :" + cust.getCustName());
		System.out.println("limit :" + cust.getCreditLimit());

	}
	
	@Test
	@Ignore
	public void testUpdateCustomer() {
		Session session=HibernateUtil.getSession();
		
		Transaction txn=session.beginTransaction();
		Customer cust=(Customer) session.get(Customer.class, 1);
		txn.commit();
		
		session=HibernateUtil.getSession();
		txn=session.beginTransaction();
		cust.setCreditLimit(500);
		session.saveOrUpdate(cust);
		txn.commit();
	}
	
	@Test
	public void testFetchDepartment() {
		
		Session session=HibernateUtil.getSession();
		
		Department dept=(Department) session.get(Department.class, 4);
		System.out.println("dept name :"+ dept.getDepname());
		System.out.println("total employee:"+dept.getEmployees().size());
		
		Transaction txn=session.beginTransaction();
		
		session.delete(dept);
		txn.commit();
		
	}
	
	
	

}
