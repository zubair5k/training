package com.lti.test;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import com.lti.entity.Employee;
import com.lti.entity.Department;

//import com.lti.pojo.Department;
//import com.lti.pojo.Employee;
import com.lti.util.HibernateUtil;

public class TestEmpDept {

	@Test
	public void testSaveEmployee() {
		Session session=HibernateUtil.getSession();
	
		Department dept=new Department();
		dept.setDepname("sales");
		
		Employee emp=new Employee();
		emp.setEmpName("polo");
		emp.setSalary(5000);
		emp.setDept(dept);
		
		Employee emp2=new Employee();
		emp2.setEmpName("harshit");
		emp2.setSalary(4000);
		emp2.setDept(dept);
		
		Transaction txn=session.beginTransaction();
		
		session.save(dept);
		session.save(emp);
		session.save(emp2);
		
		txn.commit();
	
	}
	
}
