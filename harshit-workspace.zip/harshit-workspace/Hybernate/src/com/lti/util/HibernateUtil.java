package com.lti.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public final class HibernateUtil {

	private HibernateUtil() {
	
		
	}
	
	public static Session getSession() {
		Configuration config=new Configuration().configure();
		SessionFactory factory=config.buildSessionFactory();
		return factory.openSession();
		
	}
	
}
