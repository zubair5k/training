package com.lti.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="dept")
public class Department {
	
	
	@Id
	@GeneratedValue
	@Column(name="dep_id")
	private int depId;
	@Column(name="dep_name")
	private String depname;
	
	@OneToMany(mappedBy="dept", fetch=FetchType.EAGER, cascade= {CascadeType.ALL})
	private Set<Employee> employees;
	
	
	public int getDepId() {
		return depId;
	}
	public void setDepId(int depId) {
		this.depId = depId;
	}
	public String getDepname() {
		return depname;
	}
	public void setDepname(String depname) {
		this.depname = depname;
	}
	
	public Set<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
}
