package hibernate.inheritance;

public class BankAccount extends BillingDetails {
	
	private String bankName;
	
	public String getBankName() {
		
		return bankName;
	}
	
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "BankACCOUNT [bankname= "+bankName+"toString="+super.toString()+"]";
	}

}
