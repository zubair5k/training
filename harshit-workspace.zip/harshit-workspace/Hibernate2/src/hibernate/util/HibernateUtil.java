package hibernate.util;

public class HibernateUtil {

}
