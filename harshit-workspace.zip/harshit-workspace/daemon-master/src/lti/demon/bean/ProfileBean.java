package lti.demon.bean;

public class ProfileBean {
private String email,location,skill,role;
private double expSal;
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getSkill() {
	return skill;
}
public void setSkill(String skill) {
	this.skill = skill;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public double getExpSal() {
	return expSal;
}
public void setExpSal(double expSal) {
	this.expSal = expSal;
}

}
