(function() {
    var app = angular.module("store", []);
    app.controller("StoreController", function() {
        this.products = gems;
    });
    
//    app.controller("PanelController", function() {
//        this.tab = 1;
//        
//        this.selectTab = function(setTab) {
//            this.tab = setTab;
//        };
//        
//        this.isSelected = function(checkTab) {
//            return this.tab === checkTab;
//        };
//    });
    
    app.controller("ReviewController", function() {
        this.review = { };
        
        this.addReview = function(product) {
            product.reviews.push(this.review);
            this.review = { };
        };
    });
    
//    app.directive('productTitle', function() {
//        return {
//            restrict : 'E',
//            templateUrl : '08template.html'
//        };
//            
//    });
    
    app.directive('productTitle', function() {
        return {
            restrict : 'A',
            templateUrl : '08template.html'
        };
    });

    app.directive('productPanels', function() {
        return {
            restrict : 'E',
            templateUrl : '08panel.html',
            controller : function() {
                this.tab = 1;
        
                this.selectTab = function(setTab) {
                    this.tab = setTab;
                };
        
                this.isSelected = function(checkTab) {
                    return this.tab === checkTab;
                };
            },
            controllerAs : 'pc'
        };
    });
    

    var gems = [
        { 
            name : 'Eternity' , 
            price : 9.99 , 
            description : 'Some Description' , 
            canPurchase : false , 
            soldOut : true ,
            images: [ "images/01.png" , "images/02.jpg" ],
            reviews: [
                {
                    stars : 5,
                    body : "I love this gem",
                    author: "Majrul"
                },
                {
                    stars : 4,
                    body : "I like this gem",
                    author: "Zubair"
                }
            ]
        } ,
        { 
            name : 'Infinity' , 
            price : 9.99 , 
            description : 'Some Description' , 
            canPurchase : false , 
            soldOut : true ,
            images: [ "images/03.png" , "images/04.jpg" ],
            reviews: [
                {
                    stars : 4,
                    body : "I like this gem",
                    author: "Zubair"
                },
                {
                    stars : 5,
                    body : "I love this gem",
                    author: "Majrul"
                }
            ]
        }
    ];
})();