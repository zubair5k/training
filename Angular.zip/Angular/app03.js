(function() {
    var app = angular.module("store", []);
    app.controller("StoreController", function() {
        this.products = gems;
    });
    
    var gems = [
        { 
            name : 'Eternity' , 
            price : 9.99 , 
            description : 'Some Description' , 
            canPurchase : false , 
            soldOut : true ,
            images: [ "images/01.png" , "images/02.jpg" ]
        } ,
        { 
            name : 'Infinity' , 
            price : 9.99 , 
            description : 'Some Description' , 
            canPurchase : false , 
            soldOut : true ,
            images: [ "images/03.png" , "images/04.jpg" ]
        }
    ];
})();