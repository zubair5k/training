package util;
// Employee e =  Hr.getEmployee();

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateUtil {

	public static SessionFactory buildSessionFactory(String configFileName) {
		Configuration configuration = new Configuration().configure(configFileName);
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		return sessionFactory;
	}

	public static SessionFactory buildSessionFactory(Class<?>... persistentClasses) {
		Configuration configuration = new Configuration();
		for(Class<?> persistentClass : persistentClasses)
			configuration.addClass(persistentClass);
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		return sessionFactory;
	}

	public static SessionFactory buildAnnotatedSessionFactory(Class<?>... persistentClasses) {
		Configuration configuration = new Configuration();
		for(Class<?> persistentClass : persistentClasses)
			configuration.addAnnotatedClass(persistentClass);
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		return sessionFactory;
	}

}
