create or replace type cust_addr as object(
city varchar2(20), state varchar2(20), country varchar2(20));
